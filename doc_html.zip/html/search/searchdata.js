var indexSectionsWithContent =
{
  0: "aefiklmnrsuv",
  1: "filmsu",
  2: "k",
  3: "aefinrsv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

