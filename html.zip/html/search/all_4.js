var searchData=
[
  ['lecture_2ec_0',['lecture.c',['../lecture_8c.html',1,'']]]
];
