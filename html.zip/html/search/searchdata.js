var indexSectionsWithContent =
{
  0: "aefilmnrsuv",
  1: "filmsu",
  2: "aefinrsv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Pages"
};

